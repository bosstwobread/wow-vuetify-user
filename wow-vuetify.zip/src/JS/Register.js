var methods = {
    d: 1
}
alert(methods.d);
export { //很关键
    methods
}